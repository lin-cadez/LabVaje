import time
start_time = time.time()

import sys
import os
import serial.tools.list_ports


def bar(i):
	total = 4
	fill="█"
	prefix="Progress"
	length=4
	suffix='Complete'
	iterations=4

	progress = int(length * (i) / total)
	print(f'{prefix} [{fill * progress}{" " * (length - progress)}] {int(100 * (i) / total)}% {suffix}', end='\r')
	sys.stdout.flush()

	return


def find_file(file_name, search_path=os.path.expanduser("~"), prohibited_folders=None):
    prohibited_folders = prohibited_folders or ["cache", "temp", "platformio"]

    search_paths = [os.path.join(os.path.expanduser("~"), "AppData", "Local")]


    user_home = os.path.expanduser("~")
    if user_home not in search_paths:
        search_paths.append(user_home)

    for search_path in search_paths:
        for root, dirs, files in os.walk(search_path):
            dirs[:] = [d for d in dirs if all(pf.lower() not in d.lower() for pf in prohibited_folders)]

            if file_name in files:
                return os.path.join(root, file_name)

     #Just in case, če ne najde
    for root, dirs, files in os.walk(search_path):
        dirs[:] = [d for d in dirs if all(pf.lower() not in d.lower() for pf in prohibited_folders)]

        if file_name in files:
            return os.path.join(root, file_name)

    return None



def find_arduino_port():
	ports = serial.tools.list_ports.comports()
	for port in ports:
	    if "CH340" in port.description:
	        return port.device

	return None

avrdude_file_name = 'avrdude.exe'
avrdude_conf_file_name = 'avrdude.conf'

arduino_ports = find_arduino_port()
bar(1)


avrdude_exe = find_file(avrdude_file_name)
bar(2)

avrdude_conf = find_file(avrdude_conf_file_name)
bar(3)

if not avrdude_exe:
	print(f"{avrdude_file_name} not found.")

elif not avrdude_conf:
	print(f"{avrdude_conf_file_name} not found.")

elif not arduino_ports:
	print("No Arduino found on any COM port.")
else:
	arguments=f"""-C{avrdude_conf}" -v -V -patmega328p -carduino "-P{arduino_ports}" -b115200 -D "-Uflash:w:$(TargetDir)$(TargetName).hex:i"""
	bar(4)

	end_time = time.time()
	elapsed_time = end_time - start_time

	print("---------------")
	print("Command:\n", avrdude_exe)
	print("Arguments:\n", arguments)
	print("---------------")
	print(f"Execution succeded in {round(elapsed_time, 3)} seconds")

input("Press Enter to exit...")